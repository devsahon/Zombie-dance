# UAS TypeScript Server

একটি TypeScript সার্ভার যা ওলামা AI মডেলের সাথে সংযুক্ত এবং UAS Admin Panel এর জন্য ব্যাকএন্ড API সরবরাহ করে।

## 🚀 দ্রুত শুরু

### ১. ডিপেন্ডেন্সি ইনস্টল করুন

\`\`\`bash
cd server
npm install
\`\`\`

### ২. এনভায়রনমেন্ট কনফিগার করুন

`.env` ফাইলটি কপি করুন এবং আপনার প্রয়োজন অনুযায়ী সম্পাদনা করুন:

\`\`\`bash
# Server Configuration
PORT=8000
NODE_ENV=development
HOST=localhost

# Ollama Configuration
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_DEFAULT_MODEL=codellama:7b

# Security
API_KEY=your_uas_api_key_here
CORS_ORIGIN=http://localhost:3000
\`\`\`

### ৩. সার্ভার চালু করুন

**ডেভেলপমেন্ট মোড:**

\`\`\`bash
npm run dev
\`\`\`

**প্রোডাকশন মোড:**

\`\`\`bash
npm run build
npm start
\`\`\`

## 📡 API এন্ডপয়েন্টসমূহ

### Health & Status

- `GET /health` - সার্ভার হেলথ চেক
- `GET /health/detailed` - বিস্তারিত হেলথ ইনফরমেশন
- `GET /status` - সিস্টেম স্ট্যাটাস
- `GET /status/agents` - এজেন্ট স্ট্যাটাস
- `GET /status/models` - মডেল স্ট্যাটাস

### Chat & AI

- `POST /chat/message` - চ্যাট মেসেজ পাঠান
- `POST /chat/stream` - স্ট্রিমিং চ্যাট
- `POST /chat/generate` - টেক্সট জেনারেশন
- `GET /chat/history` - চ্যাট হিস্টরি

### Models

- `GET /models` - সব মডেলের লিস্ট
- `GET /models/:modelName` - নির্দিষ্ট মডেলের তথ্য
- `POST /models/pull` - নতুন মডেল ডাউনলোড
- `POST /models/test` - মডেল টেস্ট

### Agents

- `GET /agents` - সব এজেন্টের লিস্ট
- `GET /agents/:agentId/status` - এজেন্ট স্ট্যাটাস
- `POST /agents/:agentId/start` - এজেন্ট শুরু করুন
- `POST /agents/:agentId/stop` - এজেন্ট বন্ধ করুন
- `POST /agents/:agentId/call` - এজেন্ট কল করুন

### Memory

- `GET /memory/conversations` - কনভারসেশন লিস্ট
- `GET /memory/:conversationId` - কনভারসেশন মেসেজ
- `POST /memory/store` - ডেটা স্টোর করুন
- `GET /memory/retrieve/:key` - ডেটা রিট্রিভ করুন
- `POST /memory/search` - মেমোরি সার্চ করুন

### CLI Agent

- `POST /cli-agent/execute` - কমান্ড এক্সিকিউট করুন
- `GET /cli-agent/system-info` - সিস্টেম ইনফরমেশন
- `GET /cli-agent/allowed-commands` - অনুমোদিত কমান্ড
- `POST /cli-agent/test` - CLI টেস্ট

### Editor Integration

- `POST /editor/send` - এডিটরে কনটেন্ট পাঠান
- `GET /editor/file-info` - ফাইল ইনফরমেশন
- `GET /editor/list-directory` - ডিরেক্টরি লিস্ট
- `GET /editor/test` - এডিটর টেস্ট

## 🔧 কনফিগারেশন

### Ollama সেটআপ

1. Ollama ইনস্টল করুন: <https://ollama.ai/>
2. একটি মডেল ডাউনলোড করুন: `ollama pull codellama:7b`
3. Ollama সার্ভার চালু করুন: `ollama serve`

### এনভায়রনমেন্ট ভ্যারিয়েবল

\`\`\`bash
# সার্ভার কনফিগারেশন
PORT=8000
NODE_ENV=development
HOST=localhost

# ওলামা কনফিগারেশন
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_DEFAULT_MODEL=codellama:7b

# ডাটাবেজ (ঐচ্ছিক)
DATABASE_URL=mysql://root:password@localhost:3306/uas_admin

# নিরাপত্তা
API_KEY=your_uas_api_key_here
SESSION_SECRET=your_session_secret_here
CORS_ORIGIN=http://localhost:3000

# ফিচার ফ্ল্যাগ
MEMORY_AGENT_ENABLED=true
CLI_AGENT_ENABLED=true
LOAD_BALANCER_ENABLED=true
AUDIO_CHAT_ENABLED=false
\`\`\`

## 🌐 WebSocket সাপোর্ট

সার্ভার WebSocket কানেকশন সাপোর্ট করে রিয়েল-টাইম আপডেটের জন্য:

\`\`\`javascript
const ws = new WebSocket('ws://localhost:8000');

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Received:', data);
};

// ইভেন্ট সাবস্ক্রাইব করুন
ws.send(JSON.stringify({
  type: 'subscribe',
  data: { events: ['agent.status', 'metrics.update'] }
}));
\`\`\`

## 📊 মনিটরিং

### লগ ফাইল

- `logs/error.log` - এরর লগ
- `logs/combined.log` - সব লগ
- `logs/exceptions.log` - এক্সেপশন লগ

### হেলথ চেক

\`\`\`bash
curl http://localhost:8000/health
\`\`\`

## 🔒 নিরাপত্তা

- API Key অথেনটিকেশন
- CORS কনফিগারেশন
- পাথ ট্রাভার্সাল সুরক্ষা
- কমান্ড এক্সিকিউশন সীমাবদ্ধতা
- রেট লিমিটিং

## 🚀 Admin Panel এর সাথে সংযোগ

Admin Panel এর `.env.local` ফাইলে এই URL যোগ করুন:

\`\`\`bash
UAS_API_URL=http://localhost:8000
UAS_API_KEY=your_uas_api_key_here
\`\`\`

## 🛠️ ট্রাবলশুটিং

### ওলামা কানেকশন সমস্যা

\`\`\`bash
# ওলামা সার্ভার চেক করুন
curl http://localhost:11434/api/tags

# ওলামা রিস্টার্ট করুন
ollama serve
\`\`\`

### পোর্ট কনফ্লিক্ট

\`\`\`bash
# পোর্ট 8000 ব্যবহারে আছে কিনা চেক করুন
netstat -ano | findstr :8000
\`\`\`

### লগ চেক করুন

\`\`\`bash
tail -f logs/combined.log
\`\`\`

## 📝 ডেভেলপমেন্ট

### নতুন রুট যোগ করুন

1. `src/routes/` ফোল্ডারে নতুন রুট ফাইল তৈরি করুন
2. `src/index.ts` এ রুট ইমপোর্ট করুন
3. `app.use('/new-route', newRouteRouter)` যোগ করুন

### নতুন সার্ভিস যোগ করুন

1. `src/services/` ফোল্ডারে সার্ভিস ফাইল তৈরি করুন
2. প্রয়োজন অনুযায়ী রুটে ব্যবহার করুন

## 📄 লাইসেন্স

MIT License

## 🤝 সহায়তা

কোনো সমস্যা হলে লগ ফাইল চেক করুন বা GitHub এ ইস্যু তৈরি করুন।
